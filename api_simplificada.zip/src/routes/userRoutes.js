const express = require('express');
const router = express.Router();
const ctrl = require('../controllers/userController');

router.post('/', ctrl.create);
router.post('/login', ctrl.login);
router.get('/', ctrl.list);

module.exports = router;