const User = require('../models/user');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

exports.create = async (req, res) => {
    const { name, email, password } = req.body;
    const hash = await bcrypt.hash(password, 10);
    const user = await User.create({ name, email, password: hash });
    res.json(user);
};

exports.login = async (req, res) => {
    const { email, password } = req.body;
    const user = await User.findOne({ where: { email } });
    if (!user) return res.status(400).send('Usuário não encontrado');
    const valid = await bcrypt.compare(password, user.password);
    if (!valid) return res.status(400).send('Senha inválida');
    const token = jwt.sign({ id: user.id }, process.env.JWT_SECRET);
    res.json({ token });
};

exports.list = async (req, res) => {
    const users = await User.findAll();
    res.json(users);
};