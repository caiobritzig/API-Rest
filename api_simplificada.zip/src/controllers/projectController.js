const Project = require('../models/project');

exports.create = async (req, res) => {
    const project = await Project.create(req.body);
    res.json(project);
};

exports.list = async (req, res) => {
    const projects = await Project.findAll();
    res.json(projects);
};