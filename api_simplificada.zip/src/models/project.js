const { DataTypes } = require('sequelize');
const db = require('../config/database');

const Project = db.define('Project', {
    name: DataTypes.STRING,
    description: DataTypes.STRING
});

module.exports = Project;