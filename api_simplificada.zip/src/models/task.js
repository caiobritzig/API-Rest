const { DataTypes } = require('sequelize');
const db = require('../config/database');

const Task = db.define('Task', {
    title: DataTypes.STRING,
    status: DataTypes.BOOLEAN
});

module.exports = Task;