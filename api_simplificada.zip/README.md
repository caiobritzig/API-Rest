# API Simplificada - Node.js + Sequelize

## Instalação

1. Instale dependências:
```bash
npm install
```
2. Configure o banco MySQL e o `.env`
3. Rode o projeto:
```bash
npm start
```

## Rotas

- POST /api/users
- POST /api/users/login
- CRUD /api/projects
- CRUD /api/tasks